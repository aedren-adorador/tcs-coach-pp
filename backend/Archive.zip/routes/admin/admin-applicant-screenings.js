const express = require('express');
const JobApplication = require('../../models/jobApplications');
const router = express.Router();
const {generateInterviewToken, sendInterviewInvite} = require('../../configs/email-config');
const Applicant = require('../../models/applicants');
const fs = require('fs');
const Criteria = require('../../models/criteria');


router.get('/get-job-applications-joined-with-applicants', async (req, res, next) => {
  const result = await JobApplication.aggregate([
  {
    $lookup: {
      from: 'applicants',  
      let: { localFieldConverted: { $toObjectId: '$applicantIDForeignKeyM' } },
      pipeline: [
        {
          $match: {
            $expr: {
              $eq: ['$_id', '$$localFieldConverted']
            }
          }
        }
      ],
      as: 'applicantJoinedDetails'  // merged data array
    }
  },
]).exec();
res.json({joinedApplicantAndJobApplicationDetails: result})
});

router.post('/send-interview-invite', async (req, res, next) => {
  const details = req.body
  const stringifiedDeadline = new Date(details.oneWeekDeadline).toDateString()
  const update = await JobApplication.aggregate([
            {
              $lookup: {
                from: 'applicants',  
                let: { localFieldConverted: { $toObjectId: '$applicantIDForeignKeyM' } },
                pipeline: [
                  {
                    $match: {
                      $expr: {
                        $eq: ['$_id', '$$localFieldConverted']
                      }
                    }
                  }
                ],
                as: 'applicantJoinedDetails'
              }
            },
          ]).exec();
  const filteredUpdate = update.filter(jobApp => jobApp._id.toString() === req.body.jobApplicationID)
  const filteredUpdateLevel2 = [{...filteredUpdate[0], currentStepM: 'waitingForInterviewSubmission'}]
  const token = generateInterviewToken(req.body.applicantID, req.body.jobApplicationID)
  JobApplication.updateOne({_id: req.body.jobApplicationID}, {currentStepM: 'waitingForInterviewSubmission', interviewTokenM: token, interviewQuestionsM: details.jobQuestions})
    .then(
      sendInterviewInvite(details.emailAddress, details.position, stringifiedDeadline, details.firstName)
        .then(result => {
          JobApplication.updateOne({_id: req.body.jobApplicationID}, {deadlineDateInterviewM: new Date(details.oneWeekDeadline)})
            .then(
              res.json({success: 'Interview Invite Sent via Email!', joinedApplicantAndJobApplicationDetails: filteredUpdateLevel2})
            )  
        })
    )
})

router.get('/get-applicants', (req, res, next) => {
  Applicant.find()
    .then(applicants => {
      res.json({applicants: applicants})
    })
})

router.get('/get-interview-responses/:details', (req, res, next) => {
  const details = JSON.parse(req.params.details)
  fs.readdir(`${process.env.INTERVIEW_STATIC}/${details.applicantFirstName}-${details.applicantLastName}-${details.applicantID}`, (err, files) => {
    const filteredFiles = files.filter(file => file !== '.DS_Store')
    res.send(filteredFiles);
  })
})

router.get('/populate-criteria', (req, res, next) => {
  Criteria.find()
    .then(result => res.send(result))
})

router.post('/save-initial-criteria', (req, res, next) => {
  console.log(req.body[0])
  
  JobApplication.updateOne({_id: req.body[1]}, {interviewCriteriaScoresM: req.body[0]})
    .then(result => res.send(result))
})


module.exports = router;